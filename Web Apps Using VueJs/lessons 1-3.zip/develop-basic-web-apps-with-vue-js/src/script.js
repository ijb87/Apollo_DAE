var card = new Vue({
  el: "#card",
  data: {
    title: "Dinosaurs",
    dinos: [
      { text: "Velociraptor", weight: "15kg" },
      { text: "Triceratops", weight: "6,000kg" },
      { text: "Stegosaurus", weight: "2,500kg" }
    ]  
  },
  filters: {
  capitalize: function(value) {
    if (!value) return ''
    value = value.toString()
    return value.charAt(0).toUpperCase() + value.slice(1)
   },
    undercase: function(value) {
      if (!value) return ''
      value = value.toString()
      return value.toLowerCase()
    },
    url: function(value) {
      if(!value) return ''
      value = value.toString()
      return "https://en.wikipedia.org/wiki/" + value
    }
  }
});